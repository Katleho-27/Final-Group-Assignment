// server.js

const express = require('express');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const bodyParser = require('body-parser');

// Initialize Express app
const app = express();
const port = 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// MySQL Database connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',  // your database username
  password: '901017360',  // your database password
  database: 'university_management'  // your database name
});

// Check if database connection is successful
db.connect((err) => {
  if (err) {
    console.error('Database connection error: ', err);
  } else {
    console.log('Connected to the database');
  }
});

// JWT secret key (should be stored in .env for production)
const JWT_SECRET = 'your_secret_key';

// Register function for Admin, Institute, and Student
app.post('/:userType/register', async (req, res) => {
  const { email, password } = req.body;
  const { userType } = req.params;

  // Check if user already exists
  db.query(`SELECT * FROM ${userType} WHERE email = ?`, [email], async (err, results) => {
    if (err) return res.status(500).json({ message: 'Database error' });

    if (results.length > 0) {
      return res.status(400).json({ message: `${userType} already exists` });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Insert new user into the corresponding table
    db.query(`INSERT INTO ${userType} (email, password) VALUES (?, ?)`, [email, hashedPassword], (err, result) => {
      if (err) return res.status(500).json({ message: 'Error registering user' });

      res.status(200).json({ message: `${userType} registered successfully` });
    });
  });
});

// Login function for Admin, Institute, and Student
app.post('/:userType/login', (req, res) => {
  const { email, password } = req.body;
  const { userType } = req.params;

  // Find user in the corresponding table
  db.query(`SELECT * FROM ${userType} WHERE email = ?`, [email], async (err, results) => {
    if (err) return res.status(500).json({ message: 'Database error' });

    if (results.length === 0) {
      return res.status(400).json({ message: `${userType} does not exist` });
    }

    const user = results[0];

    // Compare password with stored hash
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Generate JWT token
    const token = jwt.sign({ userId: user.id, userType }, JWT_SECRET, { expiresIn: '1h' });

    res.status(200).json({ token });
  });
});

// Middleware to authenticate the JWT token
const authenticateToken = (req, res, next) => {
  const token = req.header('Authorization')?.replace('Bearer ', '');

  if (!token) return res.status(401).json({ message: 'Access denied, token missing' });

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) return res.status(401).json({ message: 'Invalid token' });

    req.user = decoded;  // Store decoded user info in request
    next();
  });
};

// Example of a protected route
app.get('/protected', authenticateToken, (req, res) => {
  res.status(200).json({ message: 'Protected content accessed', user: req.user });
});

// Fetch institutions
app.get('/institutions', (req, res) => {
  db.query('SELECT * FROM institutions', (err, results) => {
    if (err) return res.status(500).json({ message: 'Error fetching institutions' });

    res.status(200).json(results);
  });
});

// Fetch faculties for a specific institution
app.get('/faculties/:institutionId', (req, res) => {
  const { institutionId } = req.params;

  db.query('SELECT * FROM faculties WHERE institution_id = ?', [institutionId], (err, results) => {
    if (err) return res.status(500).json({ message: 'Error fetching faculties' });

    res.status(200).json(results);
  });
});

// Fetch courses for a specific faculty
app.get('/courses/:facultyId', (req, res) => {
  const { facultyId } = req.params;

  db.query('SELECT * FROM courses WHERE faculty_id = ?', [facultyId], (err, results) => {
    if (err) return res.status(500).json({ message: 'Error fetching courses' });

    res.status(200).json(results);
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
